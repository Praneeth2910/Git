﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FB.Entites;
using FB.Exception;
using System.Data;
namespace Flight.BL
{
    public class BL
    {

    }
}
