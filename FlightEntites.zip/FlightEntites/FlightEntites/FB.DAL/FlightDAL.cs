﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using FB.Entites;
using FB.Exception;
using System.Data;
namespace FB.DAL
{
    public class FlightDAL
    {
        SqlConnection conn = new SqlConnection(@"Data source =NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id =sqluser;password=sqluser");
   
        SqlCommand cmd;
        public bool AddFBDAl(Flightbooking entites)
        {
            bool bookadded = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_insertTicketId";
                cmd.Parameters.AddWithValue("@TicketId", entites.TicketId);
                cmd.Parameters.AddWithValue("@CustomerName",entites.CustomerName);
                cmd.Parameters.AddWithValue("@price", entites.price);
                cmd.Connection = conn;

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                    bookadded = true;
            }
            catch (FlightException ex)
            {
                throw new FlightException(ex.Message);
            }

            return bookadded;
        }

        //public List<Flightbooking> GetAllFlightDAL()
        //{
        //    List<Flightbooking> Flightlist = null;

        //    try
        //    {
        //        cmd = new SqlCommand();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "udp_getbooks";
        //        cmd.Connection = conn;
        //        conn.Open();

        //        SqlDataReader dr = cmd.ExecuteReader();

        //        booklist = new List<Book>();
        //        while (dr.Read())
        //        {
        //            Book book = new Book();
        //            book.BookId = dr.GetInt32(0);
        //            book.BookName = dr.GetString(1);
        //            book.Author = dr.GetString(2);
        //            book.Price = dr.GetDouble(3);

        //            booklist.Add(book);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new BookException(ex.Message);
        //    }
        //    return booklist;
        //}

        public Flightbooking GetFlightDAL(int id)
        {
            Flightbooking entites = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_getticketbyId";
                cmd.Parameters.AddWithValue("@TicketId", id);
                cmd.Connection = conn;

                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    entites = new Flightbooking();
                    entites.TicketId = dr.GetInt32(0);
                    entites.CustomerName = dr.GetString(1);
                    entites.price = dr.GetDouble(2);
                }
            }
            catch (FlightException ex)
            {
                throw new FlightException(ex.Message);
            }
            return entites;
        }

        //public bool UpdateBookDAL(Book book)
        //{
        //    bool bookupdate = false;

        //    try
        //    {
        //        cmd = new SqlCommand();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "udp_updatebook";
        //        cmd.Parameters.AddWithValue("@name", book.BookName);
        //        cmd.Parameters.AddWithValue("@author", book.Author);
        //        cmd.Parameters.AddWithValue("@price", book.Price);
        //        cmd.Parameters.AddWithValue("@id", book.BookId);
        //        cmd.Connection = conn;

        //        conn.Open();

        //        int result = cmd.ExecuteNonQuery();

        //        conn.Close();

        //        if (result > 0)
        //            bookupdate = true;
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //    return bookupdate;
       // }

        public bool DeleteFlightDAL(int id)
        {
            bool Flightdelete = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_CancelTicket";
                cmd.Parameters.AddWithValue("@id", id);

                cmd.Connection = conn;

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                    Flightdelete = true;
            }
            catch (FlightException ex)
            {
                throw new FlightException(ex.Message);
            }
            return Flightdelete ;
        }
    }
}
